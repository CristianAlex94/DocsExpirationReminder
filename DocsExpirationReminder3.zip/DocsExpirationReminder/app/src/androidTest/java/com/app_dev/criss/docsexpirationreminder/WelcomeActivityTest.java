package com.app_dev.criss.docsexpirationreminder;

import static org.junit.Assert.*;

public class WelcomeActivityTest {

}